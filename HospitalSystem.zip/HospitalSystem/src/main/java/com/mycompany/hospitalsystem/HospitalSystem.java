/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalsystem;

/**
 *
 * @author Chelsea
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
        
       
public class HospitalSystem {
    private ArrayList<Patient> patients;
    private Bed[][] beds; //4 rows by 5 columns
    private final int ROWS = 4;
    private final int COLS = 5;
    
    public HospitalSystem(){
        patients = new ArrayList<>();
        beds = new Bed[ROWS][COLS];
        
        //create beds B01 to B20
        int num = 1;
        for(int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                String id = "B" + String.format("%02d", num);
                beds[i][j] = new Bed(id);
                num++;
            }
        }
    }
    
    //regiter a new patient
    public void  registerPatient(Patient p){
        //check for duplicate id 
        for (Patient temp : patients){
            if (temp.getPatientId().equalsIgnoreCase(p.getPatientId())){
                System.out.println("Error: Patient ID already exists!");
                return;
            }
        }
        patients.add(p);
        System.out.println("Patient regitered successfully.");
    }
    
    //Search for patient
    public Patient searchPatient(String id){
        for (Patient p : patients){
            if (p.getPatientId().equalsIgnoreCase(id)){
                return p;
            }
        }
        return null;
    }
    
    //update patient
    public void updatePatient(String id, String firstName, String lastName, int age, String gender, String condition){
        Patient p = searchPatient(id);
        if (p == null){
            System.out.println("Patient not found.");
            return;
        }
        
        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalConditon(condition);
        System.out.println("Patient updated.");
    }
    
    //delete patient
    public void deletePatient(String id){
        Patient p = searchPatient(id);
        if (p == null){
            System.out.println("Patient not found.");
            return;
        }
        
        // if inpatient has a bed, release it first
        if (p instanceof Inpatient){
            Inpatient in = (Inpatient) p;
            if (in.getBedNumber() != null){
                releaseBed(in.getBedNumber());
            }
        }
        
        patients.remove(p);
        System.out.println("Patient deleted.");
    }
    
    //display all patients
    public void displayAllPatients(){
        if (patients.isEmpty()){
            System.out.println("No patients registered.");
            return;
        }
        System.out.println("\n--- All Patients---");
        for (Patient p : patients){
            p.displayDetails();
        }
    }
    
    //allocate bed
    public void allocateBed(String patientId, String bedId){
        Patient p = searchPatient(patientId);
        if (p == null){
            System.out.println("Patient not found.");
            return;
        }
        
        if (p.getCategory() != PatientCategory.INPATIENT){
            System.out.println("Only inpatients can get a bed.");
            return;
        }
        
        Inpatient in = (Inpatient) p;
        
        if (in.getBedNumber() != null){
            System.out.println("This patient already has a bed.");
            return;
        }
        
        //find the bed
        Bed bed = null;
        for (int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                if (beds[i][j].getBedId().equalsIgnoreCase(bedId)){
                    bed = beds[i][j];
                    break;
                }
            }
        }
        
        if (bed == null){
            System.out.println("Invalid bed ID.");
            return;
        }else if (bed.isOccupied()){
            System.out.println("That bed is already occupied.");
            return;
        }else if (getAvailableBeds() == 0){
            System.out.println("No beds available.");
            return;
        }
        
        bed.allocate(patientId);
        in.setWardNumber("W1");
        in.setBedNumber(bedId);
        System.out.println("Bed allocated successfully.");
    }
    
    //release bed
    public void releaseBed(String bedId){
        Bed bed = null;
        for (int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                if (beds[i][j].getBedId().equalsIgnoreCase(bedId)){
                    bed = beds[i][j];
                    break;
                }
            }
        }
        
        if (bed == null){
            System.out.println("Invalid bed ID.");
            return;
        }
        if (!bed.isOccupied()){
            System.out.println("Bed is already free.");
            return;
        }
        
        String pid = bed. getPatientId();
        bed.release();
        
        //clear bed info patient
        Patient p = searchPatient(pid);
        if (p instanceof Inpatient){
            Inpatient in = (Inpatient) p;
            in.setBedNumber(null);
            in.setWardNumber(null);
        }
        
        System.out.println("Bed released.");
    }
    
    //show ward layout
    public void displayWardLayout(){
        System.out.println("\n--- WARD LAYOUT (4x5) ---");
        for (int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                if (beds[i][j].isOccupied()){
                    System.out.println(beds[i][j].getBedId()+"* ");
                }else{
                    System.out.println(beds[i][j].getBedId()+" ");
                }
            }
            System.out.println();
        }
        System.out.println("(* means occupied)");
    }
    
    public void displayAvailableBeds(){
        System.out.println("\n--- Available Beds --- ");
        boolean found = false;
        for (int i =0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                if (!beds[i][j].isOccupied()){
                    System.out.print(beds[i][j].getBedId());
                    found = true;
                }
            }
        }
        if (!found){
            System.out.println("No available beds.");
        }
    }
    
    public void displayOccupiedBeds(){
       System.out.println("\n--- OCCUPIED BEDS ---");
        boolean found = false;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (beds[i][j].isOccupied()) {
                    System.out.println(beds[i][j].getBedId() + " - Patient: " + beds[i][j].getPatientId());
                    found = true;
                }
            }
        }
        if (!found) {
            System.out.println("No occupied beds.");
        }
    }
    
    public int getAvailableBeds() {
        int count = 0;
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (!beds[i][j].isOccupied()) {
                    count++;
                }
            }
        }
        return count;
    }

    public int getOccupiedBeds() {
        return 20 - getAvailableBeds();
    }

    public double getOccupancy() {
        return (getOccupiedBeds() * 100.0) / 20;
    }

    // full report
    public void generateReport() {
        System.out.println("\n---------- WARD REPORT ----------");
        displayAllPatients();
        displayAvailableBeds();
        displayOccupiedBeds();
        System.out.println("Total patients: " + patients.size());
        System.out.println("Occupied beds: " + getOccupiedBeds());
        System.out.println("Occupancy: " + getOccupancy() + "%");
        System.out.println("---------------------------------");
    }

    // sort by surname
    public void sortBySurname() {
        Collections.sort(patients, new Comparator<Patient>() {
            public int compare(Patient p1, Patient p2) {
                return p1.getLastName().compareToIgnoreCase(p2.getLastName());
            }
        });
        System.out.println("Sorted by surname.");
    }

    // sort by id
    public void sortById() {
        Collections.sort(patients, new Comparator<Patient>() {
            public int compare(Patient p1, Patient p2) {
                return p1.getPatientId().compareToIgnoreCase(p2.getPatientId());
            }
        });
        System.out.println("Sorted by Patient ID.");
    }

    public ArrayList<Patient> getPatients() {
        return patients;
    }
}
