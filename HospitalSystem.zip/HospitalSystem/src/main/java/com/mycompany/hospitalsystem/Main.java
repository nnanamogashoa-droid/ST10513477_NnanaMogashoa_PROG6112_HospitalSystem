/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;

/**
 *
 * @author Chelsea
 */
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HospitalSystem system = new HospitalSystem();
        int choice = -1;

        System.out.println("====================================");
        System.out.println(" MediCare Hospital Admission System");
        System.out.println("====================================");

        while (choice != 0) {
            System.out.println("\n----- MENU -----");
            System.out.println("1. Register patient");
            System.out.println("2. Search patient");
            System.out.println("3. Update patient");
            System.out.println("4. Delete patient");
            System.out.println("5. Display all patients");
            System.out.println("6. Allocate bed");
            System.out.println("7. Release bed");
            System.out.println("8. Show ward layout");
            System.out.println("9. Show available beds");
            System.out.println("10. Show occupied beds");
            System.out.println("11. Generate report");
            System.out.println("12. Sort patients");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            try {
                choice = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Please enter a number.");
                continue;
            }

            if (choice == 1) {
                // register
                System.out.print("Patient ID: ");
                String id = sc.nextLine();
                System.out.print("First name: ");
                String first = sc.nextLine();
                System.out.print("Last name: ");
                String last = sc.nextLine();
                System.out.print("Age: ");
                int age = Integer.parseInt(sc.nextLine());
                System.out.print("Gender: ");
                String gender = sc.nextLine();
                System.out.print("Medical condition: ");
                String condition = sc.nextLine();

                System.out.println("1 = Inpatient");
                System.out.println("2 = Outpatient");
                System.out.println("3 = Emergency");
                System.out.print("Category: ");
                int cat = Integer.parseInt(sc.nextLine());

                Patient p = null;
                if (cat == 1) {
                    p = new Inpatient(id, first, last, age, gender, condition, null, null);
                } else if (cat == 2) {
                    p = new Patient(id, first, last, age, gender, condition, PatientCategory.OUTPATIENT);
                } else if (cat == 3) {
                    p = new Patient(id, first, last, age, gender, condition, PatientCategory.EMERGENCY);
                } else {
                    System.out.println("Invalid category.");
                    continue;
                }

                system.registerPatient(p);

            } else if (choice == 2) {
                System.out.print("Enter Patient ID: ");
                String id = sc.nextLine();
                Patient p = system.searchPatient(id);
                if (p == null) {
                    System.out.println("Patient not found.");
                } else {
                    p.displayDetails();
                }

            } else if (choice == 3) {
                System.out.print("Enter Patient ID to update: ");
                String id = sc.nextLine();
                System.out.print("New first name: ");
                String first = sc.nextLine();
                System.out.print("New last name: ");
                String last = sc.nextLine();
                System.out.print("New age: ");
                int age = Integer.parseInt(sc.nextLine());
                System.out.print("New gender: ");
                String gender = sc.nextLine();
                System.out.print("New condition: ");
                String condition = sc.nextLine();
                system.updatePatient(id, first, last, age, gender, condition);

            } else if (choice == 4) {
                System.out.print("Enter Patient ID to delete: ");
                String id = sc.nextLine();
                system.deletePatient(id);

            } else if (choice == 5) {
                system.displayAllPatients();

            } else if (choice == 6) {
                System.out.print("Patient ID: ");
                String pid = sc.nextLine();
                system.displayAvailableBeds();
                System.out.print("Bed ID (e.g. B01): ");
                String bedId = sc.nextLine();
                system.allocateBed(pid, bedId);

            } else if (choice == 7) {
                System.out.print("Bed ID to release: ");
                String bedId = sc.nextLine();
                system.releaseBed(bedId);

            } else if (choice == 8) {
                system.displayWardLayout();

            } else if (choice == 9) {
                system.displayAvailableBeds();

            } else if (choice == 10) {
                system.displayOccupiedBeds();

            } else if (choice == 11) {
                system.generateReport();

            } else if (choice == 12) {
                System.out.println("1 = Sort by surname");
                System.out.println("2 = Sort by Patient ID");
                System.out.print("Choice: ");
                int s = Integer.parseInt(sc.nextLine());
                if (s == 1) {
                    system.sortBySurname();
                } else if (s == 2) {
                    system.sortById();
                }
                system.displayAllPatients();

            } else if (choice == 0) {
                System.out.println("Goodbye!");
            } else {
                System.out.println("Invalid option.");
            }
        }

        sc.close();
    }
}