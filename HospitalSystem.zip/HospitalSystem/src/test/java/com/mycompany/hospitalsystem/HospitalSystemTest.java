/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HospitalSystemTest {

    private HospitalSystem system;

    @BeforeEach
    public void setUp() {
        system = new HospitalSystem();
    }

    @Test
    public void testRegisterPatient() {
        Patient p = new Patient("P001", "John", "Doe", 30, "M", "Flu", PatientCategory.OUTPATIENT);
        system.registerPatient(p);
        assertEquals(1, system.getPatients().size());
    }

    @Test
    public void testSearchPatient() {
        Patient p = new Patient("P002", "Jane", "Smith", 25, "F", "Cold", PatientCategory.EMERGENCY);
        system.registerPatient(p);
        
        assertNotNull(system.searchPatient("P002"));
        assertNull(system.searchPatient("XYZ99"));
    }

    @Test
    public void testUpdatePatient() {
        Patient p = new Patient("P003", "Bob", "Brown", 40, "M", "Asthma", PatientCategory.OUTPATIENT);
        system.registerPatient(p);
        
        system.updatePatient("P003", "Robert", "Brown", 41, "M", "Severe Asthma");
        
        Patient updated = system.searchPatient("P003");
        assertEquals("Robert", updated.getFirstName());
        assertEquals(41, updated.getAge());
    }

    @Test
    public void testDeletePatient() {
        Patient p = new Patient("P004", "Alice", "Green", 22, "F", "Headache", PatientCategory.OUTPATIENT);
        system.registerPatient(p);
        
        system.deletePatient("P004");
        assertEquals(0, system.getPatients().size());
    }

    @Test
    public void testPreventDuplicateId() {
        Patient p1 = new Patient("P005", "Tom", "White", 35, "M", "Fever", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P005", "Jerry", "Black", 28, "M", "Cough", PatientCategory.EMERGENCY);
        
        system.registerPatient(p1);
        system.registerPatient(p2);   // should not be added
        
        assertEquals(1, system.getPatients().size());
    }

    @Test
    public void testAllocateBed() {
        Inpatient in = new Inpatient("P006", "Sarah", "Lee", 45, "F", "Surgery", null, null);
        system.registerPatient(in);
        
        system.allocateBed("P006", "B01");
        
        assertEquals(1, system.getOccupiedBeds());
    }

    @Test
    public void testReleaseBed() {
        Inpatient in = new Inpatient("P007", "Mike", "Jones", 50, "M", "Injury", null, null);
        system.registerPatient(in);
        system.allocateBed("P007", "B03");
        
        system.releaseBed("B03");
        
        assertEquals(0, system.getOccupiedBeds());
    }

    @Test
    public void testPreventOccupiedBed() {
        Inpatient in1 = new Inpatient("P008", "Anna", "King", 33, "F", "Pain", null, null);
        Inpatient in2 = new Inpatient("P009", "Paul", "Queen", 29, "M", "Fever", null, null);
        
        system.registerPatient(in1);
        system.registerPatient(in2);
        
        system.allocateBed("P008", "B05");
        system.allocateBed("P009", "B05");  // should fail
        
        assertEquals(1, system.getOccupiedBeds());
    }

    @Test
    public void testOnlyInpatientCanGetBed() {
        Patient out = new Patient("P010", "Lucy", "Hill", 27, "F", "Checkup", PatientCategory.OUTPATIENT);
        system.registerPatient(out);
        
        system.allocateBed("P010", "B02");  // should not work
        
        assertEquals(0, system.getOccupiedBeds());
    }

    @Test
    public void testSortBySurname() {
        system.registerPatient(new Patient("P011", "Zack", "Zebra", 20, "M", "A", PatientCategory.OUTPATIENT));
        system.registerPatient(new Patient("P012", "Anna", "Apple", 22, "F", "B", PatientCategory.OUTPATIENT));
        system.registerPatient(new Patient("P013", "Mike", "Middle", 25, "M", "C", PatientCategory.EMERGENCY));
        
        system.sortBySurname();
        
        assertEquals("Apple", system.getPatients().get(0).getLastName());
        assertEquals("Zebra", system.getPatients().get(2).getLastName());
    }
}